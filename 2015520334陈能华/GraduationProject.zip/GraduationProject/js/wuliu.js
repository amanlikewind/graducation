function wuliu(){
		$("#btn").onclick=function(){
			ajax({
			url : "http://route.showapi.com/64-19",
			type : "get",
			data : {
				showapi_appid:"37226",
				showapi_sign:"44d1b0ee9a2a4df2b6777b631dcd0d71",
				com:"auto",//$("#com").value,
				nu:$("#nu").value
			},
			dataType : "json",
			success : function(data) {
				console.log(data);
				var _data = data.showapi_res_body;
				//console.log(_data);
				//动态增加物流行
				for(var i=0;i<_data.data.length;i++){
					if(i>0){
						var time=_data.data[i].time.slice(0,10);
					var time1=_data.data[i-1].time.slice(0,10);
					}
					
					var _div=document.createElement("div");
					_div.className="curr";
					if(i===0){
						_div.innerHTML="<span>"+_data.data[i].time+"</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>"+_data.data[i].context+"</span>";
						document.getElementById("msg").appendChild(_div);
					}
					else{
						if(time===time1){
							_div.innerHTML="&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<span>"+_data.data[i].time.slice(10)+"</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>"+_data.data[i].context+"</span>";
						document.getElementById("msg").appendChild(_div);
						}
						else{
							_div.innerHTML="<span>"+_data.data[i].time+"</span>&nbsp;&nbsp;&nbsp;&nbsp;<span>"+_data.data[i].context+"</span>";
						document.getElementById("msg").appendChild(_div);
						}
					}
				}
				document.getElementById("lastest").innerHTML=_data.data[0].context;		
			}
		})
		}
}