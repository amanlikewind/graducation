function remenber(){
	var _check=document.getElementById("admin");
				console.log(_check);
				_check.onclick=function(){
					//console.log(this.checked);
							var _name=document.getElementById("name").value,
							_psd=document.getElementById("pw").value;
							//console.log(_name,_psd);
					if(this.checked)
					{
							//console.log(_name,_psd);
							addCookie("name",_name,7);
							addCookie("password",_psd,7);
							console.log(document.cookie);
					}
					else
					{
						deleteCookie("name");
						deleteCookie("password");
						console.log(document.cookie);
					}
				}
				
				function addCookie(name,value,days){ 
				    var name = escape(name);  
				    var value = escape(value);
				    var _passWord=escape(_passWord);
				    var expires = new Date();  
				    expires.setTime(expires.getTime() + days * 3600000 * 24); 
				    var _expires = (typeof days) == "string" ? "" : ";expires=" + expires.toUTCString();  
				    document.cookie = name + "=" + value +_expires;  
				} 
				
					function getCookieValue(name){ 
					    var name = escape(name);
					    name += "=";
					    var allcookies = document.cookie;         
					    var index = allcookies.indexOf(name);      
					    if (index !== -1){
					        var start = index + name.length;     
					        var end = allcookies.indexOf(";",start);  
					        if (end == -1) 
					        	end = allcookies.length;
					        var value = allcookies.slice(start,end);
					        console.log(document.cookie);
					        console.log(start,end,value);
					        return (value);                    
					    }
					    else{
					        return "";  
					    }  
					}
				window.onload = function(){  
				    var userNameValue = getCookieValue("name");  
				    document.getElementById("name").value = userNameValue;  
				    var userPassValue = getCookieValue("password");  
				    document.getElementById("pw").value = userPassValue;
				    //console.log(userNameValue,userPassValue);
				}
				function deleteCookie(name){ 
					var name = escape(name);
				    var expires = new Date(0);  
				    document.cookie = name + "="+ ";expires=" + expires.toUTCString();  
				}  
}