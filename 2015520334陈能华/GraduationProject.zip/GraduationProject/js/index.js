function showSub()
{
	document.getElementsByClassName("shiPinDaQuan")[0].style.display="block";
}
function hideSub()
{
	document.getElementsByClassName("shiPinDaQuan")[0].style.display="none";
}
function showSub1()
{
	document.getElementsByClassName("yinShiJianKang")[0].style.display="block";
}
function hideSub1()
{
	document.getElementsByClassName("yinShiJianKang")[0].style.display="none";
}

function tab()
{
	var lbls=$("a",$("#lbl"));
	//console.log(lbls);
	for(var i=0;i<lbls.length;i++)
	{
		lbls[i].index=i;
		lbls[i].onmouseover=function()
		{
//			alert(this.index);
			var uls=$("ul",$("#content"));
//			console.log(uls)
			for(var j=0;j<uls.length;j++)
			{
				uls[j].style.display="none";
				lbls[j].className="";
			}
			uls[this.index].style.display="flex";
			this.className="curr";
		}
	}
}

function tab1()
{
	var btns=$("a",$("#ulRight"));
	//console.log(btns);
	for(var i=0;i<btns.length;i++)
	{
		btns[i].index=i;
		btns[i].onmouseover=function()
		{
			var divs=$("div",$("#leftOne"));
			//console.log(divs);
			for(var j=0;j<divs.length;j++)
			{
				divs[j].style.display="none";
			}
			divs[this.index].style.display="block";
		}
	}
}

function tab2()
{
	var btns=$("a",$("#ulRight2"));
	//console.log(btns);
	for(var i=0;i<btns.length;i++)
	{
		btns[i].index=i;
		btns[i].onmouseover=function()
		{
			var divs=$("div",$("#leftOne2"));
			//console.log(divs);
			for(var j=0;j<divs.length;j++)
			{
				divs[j].style.display="none";
			}
			divs[this.index].style.display="block";
		}
	}
}

function tab3()
{
	var btns=$("a",$("#ulRight3"));
	//console.log(btns);
	for(var i=0;i<btns.length;i++)
	{
		btns[i].index=i;
		btns[i].onmouseover=function()
		{
			var divs=$("div",$("#leftOne3"));
			//console.log(divs);
			for(var j=0;j<divs.length;j++)
			{
				divs[j].style.display="none";
			}
			divs[this.index].style.display="block";
		}
	}
}
function tab4()
{
	var btns=$("a",$("#ulRight4"));
	//console.log(btns);
	for(var i=0;i<btns.length;i++)
	{
		btns[i].index=i;
		btns[i].onmouseover=function()
		{
			var divs=$("div",$("#leftOne4"));
			//console.log(divs);
			for(var j=0;j<divs.length;j++)
			{
				divs[j].style.display="none";
			}
			divs[this.index].style.display="block";
		}
	}
}

function lun1(){
	var imgs=$(".one",$("#imgsBox"));
	//console.log(imgs);
	var len=imgs.length,
		currentIndex=0,
		circles=[],
		nextIndex=1;
	for(var i=0;i<len;i++){
		var _div=document.createElement("div");
		_div.index=i;
		circles.push(_div);
		$(".dote")[0].appendChild(_div);
		if(i==0){
			_div.className="curr";
		}
		_div.onclick=function(){
			if(this.index!==currentIndex){
				nextIndex=this.index;
				move();
			}
		}
	}
	$("#next1").onclick=move;
	$("#pre1").onclick=function(){
		nextIndex=currentIndex-1;
		if(nextIndex<0){
			nextIndex=len-1;
		}
		move();
	}
	function move(){
		fadeOut(imgs[currentIndex],1500);
		fadeIn(imgs[nextIndex],1500);
		circles[currentIndex].className="";
		circles[nextIndex].className="curr";
		currentIndex=nextIndex;
		nextIndex++;
		if(nextIndex>=len){
			nextIndex=0;
		}
	}
	setInterval(move,3000);
}

function lun2(){
	var imgs=$(".li_lun",$("#ul_lun"));
	var spans=$("span",$("#circles"));
	var spanArr=[];
	//console.log(spans);
	//console.log(imgs);
	var len=imgs.length,
		imgWidth=imgs[0].offsetWidth,
		currentIndex=0,
		nextIndex=1;
	$("#ul_lun").style.width=imgWidth*len+"px";
	function move(){
		var _left=-1*nextIndex*imgWidth;
		animate($("#ul_lun"),{left:_left},1000);
		currentIndex=nextIndex;
		nextIndex++;
		if(nextIndex>=len){
			nextIndex=0;
		}
	}
	for(var i=0;i<spans.length;i++){
		spans[i].index=i;
		spanArr.push(spans[i]);
		spans[i].onmouseover=function(){
			if(this.index!==currentIndex){
				nextIndex=this.index;
				move();
			}
		}
	}
	//setInterval(move,10000);
}


function lun3(){
	var imgs=$(".one",$("#imgsBox2"));
	//console.log(imgs);
	var len=imgs.length,
		currentIndex=0,
		circles=[],
		nextIndex=1;
	for(var i=0;i<len;i++){
		var _div=document.createElement("div");
		_div.index=i;
		circles.push(_div);
		$(".dote2")[0].appendChild(_div);
		if(i==0){
			_div.className="curr";
		}
		_div.onclick=function(){
			if(this.index!==currentIndex){
				nextIndex=this.index;
				move();
			}
		}
	}
	$("#next2").onclick=move;
	$("#pre2").onclick=function(){
		nextIndex=currentIndex-1;
		if(nextIndex<0){
			nextIndex=len-1;
		}
		move();
	}
	function move(){
		fadeOut(imgs[currentIndex],1500);
		fadeIn(imgs[nextIndex],1500);
		circles[currentIndex].className="";
		circles[nextIndex].className="curr";
		currentIndex=nextIndex;
		nextIndex++;
		if(nextIndex>=len){
			nextIndex=0;
		}
	}
	setInterval(move,3000);
}



























































