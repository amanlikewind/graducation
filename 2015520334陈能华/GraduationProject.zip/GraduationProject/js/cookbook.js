function history(){
	
	var lis=$("li",$(".dishes")[0]);
	console.log(lis);
	for(let i=0,len=lis.length;i<len;i++){
		lis[i].onclick=function(){
			var src=this.children[0].children[0].src;
			var _src=cookie("src");
			if(!_src){
				_src=[];
			}
			else{
				_src=JSON.parse(_src);
			}
			_src.push(src);
			cookie("src",JSON.stringify(_src),{expires:7});
			//console.log(document.cookie,_src);
		}
	} 
	function cookie(key, value, options) {
	if (typeof value === "undefined"){ // 读取cookie
		// 将所有 cookie 保存到数组中，每个元素的格式如：key=value
		var cookies = document.cookie.split("; ");
		// 遍历数组中的每个 cookie 字符串结构
		for (var i = 0, len = cookies.length; i < len; i++) {
			// 以 = 号分隔字符串，返回数组中第一个元素为 cookie名，第二个元素为 cookie 值
			var cookie = cookies[i].split("=");
			// 判断当前cookie名与待查找的cookie名称是否一致
			if (key === decodeURIComponent(cookie.shift()))
				return decodeURIComponent(cookie.join("="));
		}

		// 找不到 cookie，则返回 null
		return null;
	} 

	// 保存 cookie
	var cookie = encodeURIComponent(key) + "=" + encodeURIComponent(value);
	// 是否有其它设置，比如失效时间
	options = options || {};
	// 失效时间
	if (typeof options.expires !== "undefined") {
		if (typeof options.expires === "number") { // 失效时间是数字时间
			var date = new Date()
			date.setDate(date.getDate() + options.expires);
			cookie += ";expires=" + date.toUTCString();
		} else if (typeof options.expires === "object") {
			cookie += ";expires=" + options.expires.toUTCString();
		}
	}

	// 路径
	if (options.path)
		cookie += ";path=" + options.path;
	// 域名
	if (options.domain)
		cookie += ";domain=" + options.domain;
	// 安全链接
	if (options.secure)
		cookie += ";secure";

	// 保存 cookie
	document.cookie = cookie;
	}
}
