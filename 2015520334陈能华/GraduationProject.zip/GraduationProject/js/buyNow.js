function buyNowTab()
{
	var lis=$("li",$("#ul5"));
	var Bimg=$("#Bimg");
	//console.log(Bimg);
	//console.log(lis);
	for(var i=0;i<lis.length;i++)
	{
		lis[i].index=i;
		lis[i].onclick=function()
		{
			var imgs=$("img",$("#bigImg"));
			//console.log(imgs);
			for(var j=0;j<imgs.length;j++)
			{
				imgs[j].style.display="none";
			}
			imgs[this.index].style.display="block";
			Bimg.src="buyNowimg/doufu"+(this.index+1)+"dajing.jpg";
		}
	}
	
}

function fangda()
{
	var _bigImg=$("#bigImg");
	var _move=$("#move");
	var _fangdajing=$("#fangdajing");
	var _Bimg=$("#Bimg");
	//console.log(_bigImg,_move,_fangdajing,_Bimg);
	_bigImg.onmouseover=function(e)
	{
		e=e||event;
		_move.style.display="block";
		_fangdajing.style.display="block";
		_Bimg.style.display="block";
	}
	_bigImg.onmouseout=function(e)
	{
		e=e||event;
		_move.style.display="none";
		_fangdajing.style.display="none";
		_Bimg.style.display="none";
	}
	_bigImg.onmousemove=function(e)
	{
		e=e||event;
		var x=e.pageX;
		var y=e.pageY;
		var boxX=_bigImg.offsetLeft;
		var boxY=_bigImg.offsetTop;
		//console.log("鼠标的坐标=",x,y,"box的坐标=",boxX,boxY);
		var moveX=x-boxX-_move.offsetWidth/2;
		var moveY=y-boxY-_move.offsetHeight/2;
		if(moveX<=0)
			moveX=0;
		else if(moveX>_bigImg.offsetWidth-_move.offsetWidth)
			moveX=_bigImg.offsetWidth-_move.offsetWidth;
		if(moveY<=0)
			moveY=0;
		else if(moveY>_bigImg.offsetHeight-_move.offsetHeight)
			moveY=_bigImg.offsetHeight-_move.offsetHeight;
		_move.style.left=moveX+"px";
		_move.style.top=moveY+"px";
		
		var scaleX=moveX/(_bigImg.offsetWidth-_move.offsetWidth);
		var scaleY=moveY/(_bigImg.offsetHeight-_move.offsetHeight);
		var fangfaX=(_fangdajing.offsetWidth-_Bimg.offsetWidth)*scaleX;
		var fangdaY=(_fangdajing.offsetHeight-_Bimg.offsetHeight)*scaleY;
		_Bimg.style.left=fangfaX+"px";
		_Bimg.style.top=fangdaY+"px";
	}
}

function guajiang(e)
{
	e=e||event;
	var a=$("#a1");
	a.onclick=function()
	{
		$("#guajiang").style.display=($("#guajiang").style.display=="block")
									?"none"
									:"block";
		event.stopPropagation();
	}
	/*a.onclick=function(){
		//console.log("组织")
		event.stopPropagation();
		$("#guajiang").style.display="block";
		
	}*/
	document.onclick=function(){
		//console.log("哈哈")
		$("#guajiang").style.display="none";
	}
}

function youhui(e)//优惠块的显示与否
{
	e=e||event;
	var youhui=document.getElementsByClassName("ul11_4")[0].children[2];
	var youhuiph=document.getElementById("youhui");
	//console.log(youhui);
	youhui.onmouseover=function(){
		youhuiph.style.display="block";
	}
	youhui.onmouseout=function(){
		youhuiph.style.display="none";
	}
}

function dizhi(e){//地址栏的显示与否
	e=e||event;
	var to=document.getElementById("span1");
	//console.log(to);
	to.onclick=function()
	{
		var add=document.getElementById("dizhi");
		//console.log(add);
		add.style.display=add.style.display=="block"?"none":"block";
		event.stopPropagation();
	}
	document.onclick=function(){
		var add=document.getElementById("dizhi");
		//console.log(add);
		add.style.display="none";
	}
}

function changeDizhi(e){//切换地址
	var orDizhi=document.getElementById("span1").children[0];
	//console.log(orDizhi);
	var newDizhi=document.getElementsByClassName("dizhiDetail")[0].children;
	//console.log(newDizhi);
	for(var i=0;i<newDizhi.length;i++)
	{
		newDizhi[i].index=i;
		newDizhi[i].onclick=function(){
			//console.log(orDizhi);
			orDizhi.value=newDizhi[this.index].children[0].innerHTML;
			//console.log(orDizhi.value);
			switch (orDizhi.value){
				case "四川":
					document.getElementById("youfei").innerHTML="0.00";
					break;
				case "江苏":
					document.getElementById("youfei").innerHTML="8.00";
					break;
				case "浙江":
					document.getElementById("youfei").innerHTML="9.00";
					break;
				case "安徽":
					document.getElementById("youfei").innerHTML="11.00";
					break;
				case "河南":
					document.getElementById("youfei").innerHTML="15.00";
					break;
				case "新疆":
					document.getElementById("youfei").innerHTML="25.00";
					break;
				case "贵州":
					document.getElementById("youfei").innerHTML="5.00";
					break;
				case "海外":
					document.getElementById("youfei").innerHTML="150";
					break;
				default:
					document.getElementById("youfei").innerHTML="10.00";
					break;
			}
		}
	}
	
}

function pitch(e){
	e=e||event;
	var lis=document.getElementById("kouwei_1").children;
	//console.log(lis);
	for(var i=0;i<lis.length;i++)
	{
		lis[i].index=i;
		/*lis[i].onmouseover=function(){
			this.style.border="1px solid #be0106";
		}
		lis[i].onmouseout=function(){
			this.style.border="1px solid #b8b7bd";
		}*/
		lis[i].onclick=function(){
			for(var j=0;j<lis.length;j++)
			{
				lis[j].style.border="1px solid #b8b7bd";
			}
			
			lis[this.index].style.border="2px solid #be0106";
		}
	}
}

function add_del(e){
	e=e||event;
	var buyCount=$("#buyCount");
	//console.log(buyCount);
	var add=$("#add");
	var del=$("#del");
	//console.log(add,del)
	//console.log(typeof buyCount.value);
	//var count=Number(buyCount.value);
	//console.log(typeof count);
	add.onclick=function(){
		buyCount.value=Number(buyCount.value)+1;
	}
	del.onclick=function(){
		
		if(buyCount.value==1)
		{
			buyCount.value=1;
		}
		else
		{
			buyCount.value=Number(buyCount.value)-1;
		}
		
	}
}

function buy(){
	
	var add=$("button",$("#buy_add"))[0];//立即购买
	var add2=$("button",$("#buy_add"))[1];
	add2.onclick=function(e){
		e=e||event;
		e.preventDefault();
	}
	//console.log(add);
	//console.log(add,buyCount,kouwei_1,dizhi);
	//console.log(dizhi);
	add.onclick=function(e){
		e=e||event;
		e.preventDefault();
		var buyCount=$("#buyCount").value;//买的数量
	var kouwei_1=$("#kouwei_1").children;//四个li
	for(var i=0;i<kouwei_1.length;i++){
		if(css(kouwei_1[i],"border")=="2px solid rgb(190, 1, 6)"){
		var li=kouwei_1[i].innerHTML;
		//console.log(li);
			
		
		}
		//console.log(css(kouwei_1[i],"border"));
	}
		/*var dizhi=$("#span1").children[0].value;
		var youfei=$("#youfei").innerHTML;
		addCookie("dizhi",dizhi,7);
		addCookie("youfei",youfei,7);*/
		addCookie("kouwei",li,7);
		addCookie("buyCount",buyCount,7);
		//console.log(document.cookie);
		window.location.href="order.html";
	}
}

function addGouWuChe(){
	var add2=$("button",$("#buy_add"))[1];
	//console.log(add2);
	//console.log(document.cookie);
	add2.onclick=function(e){
		e=e||event;
		e.preventDefault();
		var name=$("#yonghuming").innerText.slice(3);
		//console.log(name);
		var kouwei_1=$("#kouwei_1").children;
		for(var i=0;i<kouwei_1.length;i++){			
			if(css(kouwei_1[i],"border")=="2px solid rgb(190, 1, 6)"){
				var _wei=kouwei_1[i].innerHTML;//买的口味
				//console.log(dd);
			}
		}
		var buyCount=$("#buyCount").value*1;//买的数量
		var product={
			wei:_wei,
			count:buyCount
		}
		var _products=cookie("products");
		if(!_products){
			_products=[];
		}
		else{
			_products=JSON.parse(_products);
		}
		var index=exists(_products,product.wei);
		if(index==-1){
			_products.push(product);
			//console.log(_wei,buyCount);
			//修改进数据库
			ajax({
						url : "php/cart.php",
						type:"get",
						dataType:"json",
						data : {
							action : "add",
							username : name,
							wei:_wei,
							count:buyCount
						}
					})
		}
		else{
			_products[index].count+=product.count;
			
			ajax({
						url : "php/cart.php",
						type:"get",
						dataType:"json",
						data : {
							action : "update",
							username : name,
							wei:_wei,
							count:_products[index].count
						}
					});
		}
		cookie("products", JSON.stringify(_products), {expires:7});
		
		function exists(products,wei) {
			for (var i = 0, len = products.length; i < len; i++) {
				if(products[i].wei ==wei) // 当前选购商品已存在
					return i; // 返回当前选购商品在数组中的下标
			}
			return -1; // 未选购当前商品
		}
		//console.log(document.cookie);
		/*var buyCount=$("#buyCount").value;//买的数量
		var kouwei_1=$("#kouwei_1").children;//四个li
		var _kouwei=cookie("wei");
//		console.log(_kouwei);
		var _buyCount=cookie("count");
		if(!_kouwei){
			_kouwei=[];
		}
		else{
			_kouwei=JSON.parse(_kouwei);
			//console.log(decodeURIComponent(_kouwei));
		}
//		console.log(_kouwei); 	
		var ll = false;
		for(var i=0;i<kouwei_1.length;i++){
			var wei=kouwei_1[i].innerHTML;
			if(css(kouwei_1[i],"border")=="2px solid rgb(190, 1, 6)"){
				var dd = kouwei_1[i].innerHTML;
				var index=i;
		*/		//console.log(dd);
		/*	}
		}
		
		
		if(!_buyCount){
			_buyCount=[];
		}
		else{
			_buyCount=JSON.parse(_buyCount);
		}
		//找到
		//console.log(_kouwei);
		_kouwei.forEach(function(curr){
			//console.log(curr);
			if(curr==dd){
				
				_buyCount[index]+=buyCount;
				ll=true;
				return;
			}
		})
		if(!ll){
			_kouwei.push(dd);
		}
		
		_buyCount.push(buyCount);
		cookie("wei",JSON.stringify(_kouwei),{expires:7});
		cookie("count",JSON.stringify(_buyCount),{expires:7});*/
		//console.log(document.cookie);
		
		/************************/
		var domAddToCart=$("#addToCart");
					/*console.log(domAddToCart);
		        domAddToCart.onclick = function (e) {
		        	e=e||event;
		        	e.preventDefault();*/
		            var domShopCart = document.getElementById('shopCart');
		            var nStartX = domAddToCart.offsetLeft + 540,
		                    nStartY = domAddToCart.offsetTop+230 - document.body.scrollTop,
		                    nEndX = 1224,
		                    nEndY = domShopCart.offsetTop+10,
		                    nTopX = nEndX - 20,
		                    nTopY = nEndY - 30;
		
		            var x = nStartX,y = nStartY,w=0,h=0;
		
		            //新建一个内容
		            var domGood = document.createElement('div');
		            domGood.className="paowuxian";
		            domGood.innerHTML="<img src='buyNowimg/doufu1.jpg' />"
		            domGood.style.width = '60px';
		            domGood.style.height = '60px';
		            domGood.style.background = '#a1000e';
		            domGood.style.position = 'fixed';
		            domGood.style.overflow='hidden';
		            domGood.style.left = nStartX + 'px';
		            domGood.style.top = nStartY + 'px';
		            document.body.appendChild(domGood);
		
		            var a = ((nStartY - nEndY) * (nStartX - nTopX) - (nStartY - nTopY) * (nStartX - nEndX)) / ((nStartX * nStartX - nEndX * nEndX) * (nStartX - nTopX) - (nStartX * nStartX - nTopX * nTopX) * (nStartX - nEndX));
		            var b = ((nEndY - nStartY) - a * (nEndX * nEndX - nStartX * nStartX)) / (nEndX - nStartX);
		            var c = nStartY - a * nStartX * nStartX - b * nStartX;
		            var timer = setInterval(function () {
		                y = a * x*x + b*x +c;
		                if (x < nEndX) {
		                    x = x + 5;
		                    w=w+0.5;
		                    h=h+0.5;
		                    y = a * x * x + b * x + c;
		                    domGood.style.left = x + 'px';
		                    domGood.style.top = y + 'px';
		                    domGood.style.width = (60-w) + 'px';
		                    domGood.style.height = (60-h) + 'px';
		                }else {
		                    domGood.parentNode.removeChild(domGood);
		                    clearInterval(timer);
		                }
		
		            }, 10);
		        
	}
}

function addCookie(name,value,days){ 
			    var name = encodeURIComponent(name);  
			    var value = encodeURIComponent(value);
			    var expires = new Date();  
			    expires.setTime(expires.getTime() + days * 3600000 * 24); 
			    var _expires = (typeof days) == "string" ? "" : ";expires=" + expires.toUTCString();  
			    document.cookie = name + "=" + value +_expires;  
			} 
			


function paowuxian(){
				
					var domAddToCart = document.getElementById('addToCart');
		        domAddToCart.onclick = function (e) {
		        	e=e||event;
		        	e.preventDefault();
		            var domShopCart = document.getElementById('shopCart');
		            var nStartX = domAddToCart.offsetLeft + 600,
		                    nStartY = domAddToCart.offsetTop+270 - document.body.scrollTop,
		                    nEndX = 1224,
		                    nEndY = domShopCart.offsetTop+10,
		                    nTopX = nEndX - 20,
		                    nTopY = nEndY - 30;
		
		            var x = nStartX,y = nStartY;
		
		            //新建一个内容
		            var domGood = document.createElement('div');
		            domGood.innerHTML="<img src='buyNowimg/doufu1.jpg' />"
		            domGood.style.width = '20px';
		            domGood.style.height = '20px';
		            domGood.style.background = '#a1000e';
		            domGood.style.position = 'fixed';
		            domGood.style.left = nStartX + 'px';
		            domGood.style.top = nStartY + 'px';
		            document.body.appendChild(domGood);
		
		            var a = ((nStartY - nEndY) * (nStartX - nTopX) - (nStartY - nTopY) * (nStartX - nEndX)) / ((nStartX * nStartX - nEndX * nEndX) * (nStartX - nTopX) - (nStartX * nStartX - nTopX * nTopX) * (nStartX - nEndX));
		            var b = ((nEndY - nStartY) - a * (nEndX * nEndX - nStartX * nStartX)) / (nEndX - nStartX);
		            var c = nStartY - a * nStartX * nStartX - b * nStartX;
		            var timer = setInterval(function () {
		                y = a * x*x + b*x +c;
		                if (x < nEndX) {
		                    x = x + 5;
		                    y = a * x * x + b * x + c;
		                    domGood.style.left = x + 'px';
		                    domGood.style.top = y + 'px';
		                }else {
		                    domGood.parentNode.removeChild(domGood);
		                    clearInterval(timer);
		                }
		
		            }, 10);
		        }
			}

function pingjia(){
	var pages=1;
	function load(_page){
					ajax({
						type:"get",
						url:"php/fenye2.php",
						data:{page:_page},
						dataType:"json",
						success:function(data){
							//console.log(data);
							pages=data.length;
							$("#pingjia").innerHTML="";
							var html="";							
							data.forEach(function(item){
								item.pingjia_shop=item.pingjia_shop?item.pingjia_shop:"";
								html+='<div class="pingjia_users">'+
						'<div class="pingjia_left">	'+						
							'<div class="pingjia_user">'+item.pingjia_user+'</div>'+
							'<div class="img_user"></div>'+
							'<div class="time_user">'+item.time+'</div>'+
							'<div class="pingjia_shop">'+item.pingjia_shop+'</div>'+
						'</div>'+
						'<div class="pingjia_right">'+item.username+'</div>'+
					'</div>';
							});
							$("#pingjia").innerHTML=html;
						}
					});
				}
	var page=1;
	load(page);
	$("#shouye").onclick=function(){
		load(1);
	}
	$("#shangyiye").onclick=function(){
		page--;
		if(page<=1){
			page=1;
		}
		load(page);
	}
	$("#xiayiye").onclick=function(){
		page++;
		load(page);
	}
	$("#weiye").onclick=function(){
		load(pages);
	}
	
}
function tijiaopingjia(){
	var tijiao=$("#tijiao");
	tijiao.onclick=function(e){
/*		e=e||event;
		e.preventDefault();*/
		var name=$("#yonghuming").innerText.slice(3);
		//console.log(name);
		var neirong=$("#pingjia_wei").value;
		//console.log(neirong);
		var date=new Date();
		var nian=date.getFullYear();
		var yue=date.getMonth()+1;
		var ri=date.getDate();
		var shi=date.getHours();
		var fen=date.getMinutes();
		var miao=date.getSeconds();
		var time=""+nian+"-"+yue+"-"+ri+" "+shi+":"+fen+":"+miao;
		//console.log(time);
		ajax({
			type:"post",
			url:"php/updateRegister.php",
			data:{
				name:name,
				neirong:neirong,
				time:time
			}/*,
			dataType:"json",
			success:function(data){
				
			}*/
		})
	}
}

function chat(){
	//点击客服出现聊天界面
	$("#kefu").onclick=function(){
		$("#chat").style.display="block";
	}
	$("#guandiao").onclick=function(){
		$("#chat").style.display="none";
	}
	//聊天
	$("#send").onclick = function()
		{
			//console.log($("#yonghuming"));
			var _nickname=$("#yonghuming").innerText.slice(3);
			//console.log($("#msg").value);
			ajax({
				url : "php/chat.php",
				type : "get",
				data : {
					nickname : _nickname,
					msg : $("#msg").value,
					action : "write"
				},
				success : function(data){
					// 将当前发送消息追加到所有消息之后：
					/*$("#info").innerHTML += "<div>"+ _nickname +" 说："+ $("#msg").value +"</div>";*/

					// 将消息滚动到最后
					/*var _div = document.createElement("div");
					$("#info").appendChild(_div);
					_div.scrollIntoView();*/

					// 清空已发送消息
					$("#msg").value = "";
				}
			});
		}
		/*随时刷新聊天记录*/
		setInterval(function(){
			ajax({
				url : "php/chat.php",
				type : "get",
				data : {
					action : "read"
				},
				dataType : "json",
				success : function(data){ // data是拿到的所有聊天消息数组结构
					//console.log(data);
					$("#info").innerHTML = "";
					data.forEach(function(current,index){
						var dir ="leftleft";
						var bianse="xiaoxi2";
						var len=data.length;
						if(current.name!=="admin1"){
							dir="rightright";
							bianse="xiaoxi";
						}
						$("#info").innerHTML += "<div class="+dir+">"+ current.name +"</div>";
						$("#info").innerHTML+="<div class='"+dir+" "+bianse+"'>"+ current.say +"</div>";
						
						//console.log($("div",$("#info"))[len-1]);
					});
					// 将消息滚动到最后
					//$("div",$("#info"))[1].scrollIntoView();
					/*var _div = document.createElement("div");
					$("#info").appendChild(_div);
					_div.scrollIntoView();*/
				}
			});
		}, 500);
}
