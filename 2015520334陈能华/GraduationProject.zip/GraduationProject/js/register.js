function check() { 
			var username = document.getElementById("text2");
			var password = document.getElementById("pw");
			var pw1 = document.getElementById("pw1");
			var regex = /\w{1,}/;
			username.onblur = function() {
				if (!regex.test(username.value)) {
					alert("用户名不能为空且只能是数字、字母和下划线");
					return false; 
				} else {
					//alert("对了");
				}

			}
			password.onblur = function() {
				if (!regex.test(password)) {
					alert("密码不能为空且只能是数字、字母和下划线");
					return false;     
				} else {
					//console.log("对了");
				}
			}
			pw1.onblur = function() {
					if (password.value != pw1.value) {
						alert("两次密码不一致");
						//return false; 
					}
				}
      }
    