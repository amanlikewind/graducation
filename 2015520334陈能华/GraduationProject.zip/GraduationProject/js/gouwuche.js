function che(){
	var _kouwei=getCookieValue("kouwei");
	var _buyCount=getCookieValue("buyCount");
	//console.log(_kouwei,_buyCount);
	var _div=document.createElement("div");
	_div.innerHTML="<div class='san8'><span>满38元包邮</span>&nbsp;满38享部分地区包邮</div><ul><li><input type='checkbox'></li><li><img src='"+(../buyNowimg/doufu1.jpg)+"'></li><li></li><li></li><li></li><li></li><li></li><li></li></ul>";
	$(".shenti")[0].appendChild(_div);
	
	function getCookieValue(name){
					    var name = decodeURIComponent(name);
					    //console.log(name);
					    name += "=";
					    var allcookies = document.cookie;         
					    var index = allcookies.indexOf(name);      
					    if (index !== -1){
					        var start = index + name.length;     
					        var end = allcookies.indexOf(";",start);  
					        if (end == -1) 
					        	end = allcookies.length;
					        var value =decodeURIComponent(allcookies.slice(start,end));
					        //console.log(document.cookie);
					        //console.log(start,end,value);
					        return (value);                    
					    }
					    else{
					        return "";  
					    }  
					}
	
}

