function getTime()
{
	var time=new Date()
	var year=time.getFullYear();
	var month=time.getMonth()+1;
	var day=time.getDate()
	var hour=time.getHours();
	var minute=(time.getMinutes()<10?"0"+time.getMinutes():time.getMinutes())
	var second=time.getSeconds()<10?"0"+time.getSeconds():time.getSeconds();
	var week=time.getDay();
	switch (week){
			case 0:
		week="星期日"
			break;
			case 1:
		week="星期一"
			break;
			case 2:
		week="星期二"
			break;
			case 3:
		week="星期三"
			break;
			case 4:
		week="星期四"
			break;
			case 5:
		week="星期五"
			break;
			case 6:
		week="星期六"
			break;
	}
	var timeNow=year+" 年 "+month+" 月 "+day+" 日 "+hour+":"+minute+":"+second+" "+week;
	document.getElementById("text2").value=timeNow;
	setTimeout("getTime()",1000);
}


