<?php
	$username=$_POST["username"];
	$password=$_POST["password"];
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	
	$sql="select id from admin where username='$username' and password='$password'";
	$result=mysql_query($sql,$conn);
	$id=null;
	while($row=mysql_fetch_array($result,MYSQL_ASSOC)){
		$id=$row['id'];
	}
	if(!is_null($id)){
		echo '{"status":1}';
	}
	else{
		echo '{"status":0}';
	}
?>