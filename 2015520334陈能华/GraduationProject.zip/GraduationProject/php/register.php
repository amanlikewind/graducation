<?php
	$username=$_POST["username"];
	$password=$_POST["password"];
	//echo $username,$password;
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error".mysql_error());
	}
	else{
//		echo "可以连接";
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");	
	$sql="insert into register(username,password) values('$username','$password')";
	$result=mysql_query($sql,$conn);
	if($result){
		echo '{"status":1}';
	}
	else{
		echo '{"status":0}';
	}
	
	mysql_close($conn);
?>