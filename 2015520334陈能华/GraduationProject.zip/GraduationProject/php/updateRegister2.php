<?php
	$id=$_POST["id"];
	$username=$_POST["username"];
	$password=$_POST["password"];
	$pingjia_user=$_POST["pingjia_user"];
	$time=$_POST["time"];
	$pingjia_shop=$_POST["pingjia_shop"];
	
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	
	$sql="update register set pingjia_shop='$pingjia_shop' where username='$username'";
	@mysql_query($sql);
	echo json_encode(array(
		'id' => mysql_insert_id(),
		'id' => $id,
		'username' => $username,
		'password' => $password,
		'pingjia_user' => $pingjia_user,
		'time' => $time,
		'pingjia_shop' => $pingjia_shop,
	));
?>