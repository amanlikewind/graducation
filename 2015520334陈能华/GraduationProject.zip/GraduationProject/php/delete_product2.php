<?php
	//$id = intval($_REQUEST['id']);
	$id=intval($_POST['id']);

	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");

	$sql = "delete from fenye where id='$id'";
	@mysql_query($sql);
	echo json_encode(array('success'=>true));
?>