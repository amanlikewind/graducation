<?php
	$bianhao=$_POST["id"];
	$name=$_POST["name"];
	
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");

	/*$sql="select bianhao from products where bianhao='{$bianhao}'";
	$result=mysql_query($sql,$conn);
	$dbbianhao=null;
//	$arr=array();
	while($row=mysql_fetch_array($result,MYSQL_ASSOC)){
		$dbbianhao=$row['bianhao'];
//		$arr[]=$row;
	}
	if(!is_null($dbbianhao)){
		echo '{"status":1}';
	}else{
		echo '{"status":0}';
	}*/
	
	$sql="select bianhao,mingcheng from products where bianhao='{$bianhao}' or mingcheng like '%".$name."%'";
	$result=mysql_query($sql,$conn);
	$arr=array();
	while($row=mysql_fetch_array($result,MYSQL_ASSOC)){
		$arr[]=$row;
	}
	//echo json_encode($arr);
	if(!is_null($arr)){
		echo '{"status":1}';
	}else{
		echo '{"status":0}';
	}
?>