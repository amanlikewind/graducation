<?php
	$page=$_GET["page"];
	if(!$page){
		$page=1;
	}
	$conn=mysql_connect("localhost","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set character set 'utf8'");
	mysql_query("set names 'utf8'");
	
	$sql="select * from fenye limit ".($page-1)*18 .", 18";
	$result=mysql_query($sql,$conn);
	$arr=array();
	while($row=mysql_fetch_array($result,MYSQL_ASSOC)){
		$arr[]=$row;
	}
	echo json_encode($arr);
	
	mysql_close($conn);
?>