<?php
	$bianhao = $_REQUEST['bianhao'];
	$mingcheng = $_REQUEST['mingcheng'];
	$jiage = $_REQUEST['jiage'];
	$fenlei = $_REQUEST['fenlei'];
	$kucun = $_REQUEST['kucun'];
	$tuijian = $_REQUEST['tuijian'];
	$shangjia = $_REQUEST['shangjia'];
	$rexiao = $_REQUEST['rexiao'];
	
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	
	$sql = "insert into products values('$bianhao','$mingcheng','$jiage','$fenlei','$kucun','$tuijian','$shangjia','$rexiao')";
	@mysql_query($sql);
	echo json_encode(array(
		'id' => mysql_insert_id(),
		'bianhao' => $bianhao,
		'mingcheng' => $mingcheng,
		'jiage' => $jiage,
		'fenlei' => $fenlei,
		'kucun' => $kucun,
		'tuijian' => $tuijian,
		'shangjia' => $shangjia,
		'rexiao' => $rexiao
	));
?>