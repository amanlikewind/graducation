<?php
	$name=$_POST["name"];
	$neirong=$_POST["neirong"];
	$time=$_POST["time"];
	
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	
	$sql="update register set pingjia_user='$neirong',time='$time' where username='$name'";
	@mysql_query($sql);
	/*echo json_encode(array(
		'id' => mysql_insert_id(),
		'id' => $id,
		'src' => $src,
		'span_one' => $span_one,
		'i_one' => $i_one,
		'b_one' => $b_one,
		'span_two' => $span_two,
		'span_three' => $span_three
	));*/
?>