<?php
	$username=$_POST["username"];
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	$sql="select username from register where username='{$username}'";
	$result=mysql_query($sql,$conn);
	//echo json_encode($result);
	$dbusername=null;
	$arr=array();
	while($row=mysql_fetch_array($result,MYSQL_ASSOC)){
		$dbusername=$row['username'];
		//$arr[]=$row['username'];
	}
	/*if(in_array($username, $arr)){
		echo '{"status":1}';
	}else{
		echo '{"status":0}';
	}
	*/
	if(!is_null($dbusername)){
		echo '{"status":1}';
	}else{
		echo '{"status":0}';
	}
?>