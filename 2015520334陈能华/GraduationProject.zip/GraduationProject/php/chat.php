<?php

	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	// 获取传递的用户昵称和发送的消息
	$nickname = $_GET["nickname"];
	$msg = $_GET["msg"];
	$action = $_GET["action"]; // 读消息/写消息的行为  read/write
	
	if ($action === "write"){ 
		$sql="insert into chat values('null','$nickname','$msg')";
		$result=mysql_query($sql,$conn);
		if($result){
			echo '{"status":1}';
		}
	}else if($action==="read"){
		$sql="select name,say from chat";
		$result=mysql_query($sql,$conn);
		$arr=array();
		while($row=mysql_fetch_array($result,MYSQL_ASSOC)){
			$arr[]=$row;
		}
		echo json_encode($arr);
	}
?>