<?php
	//$id = intval($_REQUEST['id']);
	$id = $_REQUEST['id'];
	$src = $_REQUEST['src'];
	$span_one = $_REQUEST['span_one'];
	$i_one = $_REQUEST['i_one'];
	$b_one = $_REQUEST['b_one'];
	$span_two = $_REQUEST['span_two'];
	$span_three = $_REQUEST['span_three'];
	
	$conn=mysql_connect("localhost:3306","root","");
	if(!$conn){
		die("error:".mysql_error());
	}
	mysql_select_db("graduation",$conn);
	mysql_query("set names 'utf8'");
	mysql_query("set character set 'utf8'");
	
	$sql="update fenye set id='$id',src='$src',span_one='$span_one',i_one='$i_one',b_one='$b_one',span_two='$span_two',span_three='$span_three' where id='$id'";
	@mysql_query($sql);
	echo json_encode(array(
		'id' => mysql_insert_id(),
		'id' => $id,
		'src' => $src,
		'span_one' => $span_one,
		'i_one' => $i_one,
		'b_one' => $b_one,
		'span_two' => $span_two,
		'span_three' => $span_three
	));
?>