﻿-- phpMyAdmin SQL Dump
-- version 2.11.2.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2017 年 05 月 27 日 07:35
-- 服务器版本: 5.0.45
-- PHP 版本: 5.2.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";CREATE DATABASE `graduation` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `graduation`;

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 导出表中的数据 `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin1', '123456');

-- --------------------------------------------------------

--
-- 表的结构 `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(20) collate utf8_unicode_ci default NULL,
  `wei` varchar(500) collate utf8_unicode_ci default NULL,
  `count` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- 导出表中的数据 `cart`
--

INSERT INTO `cart` (`id`, `username`, `wei`, `count`) VALUES
(3, 'pig10', '香菇豆干【五口味】500g装', '2'),
(4, 'pig10', '香菇豆干【五口味】1000g装', '3');

-- --------------------------------------------------------

--
-- 表的结构 `chat`
--

DROP TABLE IF EXISTS `chat`;
CREATE TABLE IF NOT EXISTS `chat` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(20) collate utf8_unicode_ci default NULL,
  `say` varchar(500) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

--
-- 导出表中的数据 `chat`
--

INSERT INTO `chat` (`id`, `name`, `say`) VALUES
(1, 'pig10', '在吗'),
(2, 'admin1', '在的'),
(3, 'pig10', '老王啊'),
(4, 'pig10', '沃日你没哦'),
(5, 'admin1', '草，你试试'),
(6, 'admin1', '不打死你');

-- --------------------------------------------------------

--
-- 表的结构 `fenye`
--

DROP TABLE IF EXISTS `fenye`;
CREATE TABLE IF NOT EXISTS `fenye` (
  `id` int(11) NOT NULL auto_increment,
  `src` varchar(50) collate utf8_unicode_ci NOT NULL default 'imgs/doufu1da.jpg',
  `span_one` varchar(50) collate utf8_unicode_ci NOT NULL default '香辣豆腐干',
  `i_one` varchar(50) collate utf8_unicode_ci NOT NULL default '6 评论 687人气',
  `b_one` varchar(50) collate utf8_unicode_ci NOT NULL default '一枝独秀4866',
  `span_two` varchar(50) collate utf8_unicode_ci NOT NULL default '5步 /大概十分钟',
  `span_three` varchar(50) collate utf8_unicode_ci NOT NULL default '炒/ 家常味',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=123 ;

--
-- 导出表中的数据 `fenye`
--

INSERT INTO `fenye` (`id`, `src`, `span_one`, `i_one`, `b_one`, `span_two`, `span_three`) VALUES
(1, 'imgs/doufu1da.jpg', '香辣豆腐干', '6评论 687人气', '一支独秀', '5步/大概十分钟', '抄/家常味'),
(2, 'imgs/index_18.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(3, 'imgs/page_1.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(4, 'imgs/index_19.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(5, 'imgs/index_20.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(6, 'imgs/index_21.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(7, 'imgs/index_22.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(8, 'imgs/index_23.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(9, 'imgs/index_24.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(10, 'imgs/index_25.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(11, 'imgs/index_26.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(12, 'imgs/index_27.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(13, 'imgs/index_28.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(14, 'imgs/index_29.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(15, 'imgs/index_30.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(16, 'imgs/index_31.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(17, 'imgs/index_32.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(18, 'imgs/index_33.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(19, 'imgs/index_34.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(20, 'imgs/index_35.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(21, 'imgs/page_2.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(22, 'imgs/page_3.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(23, 'imgs/page_4.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(24, 'imgs/page_5.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(25, 'imgs/page_6.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(26, 'imgs/page_7.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(27, 'imgs/page_8.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(28, 'imgs/page_9.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(29, 'imgs/page_10.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(30, 'imgs/page_11.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(31, 'imgs/page_12.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(32, 'imgs/page_13.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(33, 'imgs/page_14.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(34, 'imgs/page_15.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(35, 'imgs/page_16.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(36, 'imgs/page_17.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(37, 'imgs/page_18.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(38, 'imgs/page_19.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(39, 'imgs/page_20.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(40, '["http://127.0.0.1/php/GraduationProject/imgs/douf', '香辣豆腐干', '6评论 687人气', '一支独秀', '5步/大概十分钟', '抄/家常味'),
(41, 'imgs/page_22.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(42, 'imgs/page_23.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(43, 'imgs/page_24.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(44, 'imgs/page_25.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(45, 'imgs/page_26.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(46, 'imgs/page_27.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(47, 'imgs/page_28.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(48, 'imgs/page_29.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(49, 'imgs/page_30.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(50, 'imgs/page_31.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(51, 'imgs/page_32.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(52, 'imgs/page_33.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(53, 'imgs/page_34.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(54, 'imgs/page_35.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(55, 'imgs/page_36.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(56, 'imgs/page_37.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(57, 'imgs/page_38.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(58, 'imgs/page_39.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(59, 'imgs/page_40.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(60, 'imgs/page_41.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(61, 'imgs/page_42.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(62, 'imgs/page_43.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(63, 'imgs/page_44.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(64, 'imgs/page_45.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(65, 'imgs/page_46.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(66, 'imgs/page_47.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(67, 'imgs/page_48.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(68, 'imgs/page_49.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(69, 'imgs/page_50.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(70, 'imgs/page_51.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(71, 'imgs/page_52.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(72, 'imgs/page_53.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(73, 'imgs/page_54.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(74, 'imgs/page_55.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(75, 'imgs/page_56.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(76, 'imgs/page_57.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(77, 'imgs/page_58.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(78, 'imgs/page_59.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(79, 'imgs/page_63.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(80, 'imgs/page_60.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(81, 'imgs/page_61.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(82, 'imgs/page_62.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(83, 'imgs/page_64.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(84, 'imgs/page_65.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(85, 'imgs/page_66.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(86, 'imgs/page_67.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(87, 'imgs/page_68.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(88, 'imgs/page_69.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(89, 'imgs/page_70.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(90, 'imgs/page_71.jpg', '香辣豆腐干', '6 评论 687人气', '一枝独秀4866', '5步 /大概十分钟', '炒/ 家常味'),
(91, '["http://127.0.0.1/php/GraduationProject/imgs/douf', '', '', '', '', ''),
(100, '["http://127.0.0.1/php/GraduationProject/imgs/douf', '哈哈哈哈哈哈哈', '哈', '安徽', '安徽', '安徽'),
(122, '["http://127.0.0.1/php/GraduationProject/imgs/douf', '月月', '月', '月', '月', '月');

-- --------------------------------------------------------

--
-- 表的结构 `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `bianhao` int(11) NOT NULL,
  `mingcheng` varchar(50) collate utf8_unicode_ci NOT NULL,
  `jiage` decimal(50,0) NOT NULL,
  `fenlei` varchar(50) collate utf8_unicode_ci NOT NULL,
  `kucun` int(11) NOT NULL,
  `tuijian` varchar(20) collate utf8_unicode_ci default NULL,
  `shangjia` varchar(20) collate utf8_unicode_ci default NULL,
  `rexiao` varchar(20) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`bianhao`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 导出表中的数据 `products`
--

INSERT INTO `products` (`bianhao`, `mingcheng`, `jiage`, `fenlei`, `kucun`, `tuijian`, `shangjia`, `rexiao`) VALUES
(4, '麻辣香锅222', 13, '调料', 200, '是', '是', '是'),
(5, '麻辣香水鱼', 8, '调料', 300, '是', '是', '是'),
(7, '老鸭汤', 8, '调料', 500, '是', '是', '是'),
(8, '粉蒸肉', 5, '调料', 600, '是', '是', '是'),
(9, '榨菜丝', 2, '下饭菜', 100, '是', '是', '是'),
(10, '地牯牛', 8, '下饭菜', 200, '是', '是', '是'),
(11, '木耳榨菜2', 2, '下饭菜', 300, '是', '是', '是'),
(13, '山椒脆笋', 9, '下饭菜', 500, '是', '是', '是'),
(14, '秋霞火锅料', 6, '火锅料', 600, '是', '是', '是'),
(15, '桥头火锅料', 30, '火锅料', 700, '是', '是', '是'),
(16, '周君记火锅料', 62, '火锅料', 800, '是', '是', '是'),
(17, '牛油火锅料', 23, '火锅料', 900, '是', '是', '是'),
(18, '豆腐干', 10, '地方小吃', 200, '是', '是', '是'),
(19, '荷花米花糖', 39, '地方小吃', 2000, '是', '是', '是'),
(20, '合川肉片', 6, '地方小吃', 300, '是', '是', '是'),
(21, '陈麻花', 12, '地方小吃', 400, '是', '是', '是'),
(22, '芝麻片', 19, '地方小吃', 500, '是', '是', '是'),
(23, '怪味胡豆', 6, '地方小吃', 600, '是', '是', '是'),
(24, '米花酥', 70, '地方小吃', 700, '是', '是', '是'),
(25, '牛肉脯', 65, '牛肉', 800, '是', '是', '是'),
(26, '牛肉干', 34, '牛肉', 900, '是', '是', '是'),
(27, '灯影牛肉', 25, '牛肉', 1000, '是', '是', '是'),
(28, '牛肉丝', 29, '牛肉', 2000, '是', '是', '是'),
(29, '牛筋', 40, '牛肉', 3100, '是', '是', '是'),
(30, '牛皮', 30, '牛肉', 3200, '是', '是', '是'),
(31, '牛排', 59, '牛肉', 2000, '是', '是', '是'),
(32, '你好', 32, '32', 32, '是', '是', '是'),
(101, '猪头肉', 101, '猪肉', 101, '是', '是', '是');

-- --------------------------------------------------------

--
-- 表的结构 `register`
--

DROP TABLE IF EXISTS `register`;
CREATE TABLE IF NOT EXISTS `register` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `pingjia_user` varchar(150) collate utf8_unicode_ci default NULL,
  `time` date default NULL,
  `pingjia_shop` varchar(150) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=41 ;

--
-- 导出表中的数据 `register`
--

INSERT INTO `register` (`id`, `username`, `password`, `pingjia_user`, `time`, `pingjia_shop`) VALUES
(1, 'pig1', 'pig1', '好好吃', '2017-05-23', '谢谢'),
(3, 'pig2', 'pig2', '你是猪', '2017-05-23', '谢谢哦哦哦 '),
(4, 'pig3', 'pig3', '我是pig3', '2017-05-23', '你是pig3'),
(5, 'pig4', 'pig4', '我是pig4', '2017-05-23', '你是pig4'),
(6, 'pig5', 'pig5', '我是pig5', '2017-05-24', '你是pig5'),
(7, 'pig6', 'pig6', '我是pig6', '2017-05-24', '你是pig6'),
(8, 'pig7', 'pig7', '我是pig7', '2017-05-24', '你是pig7'),
(9, 'pig8', 'pig8', '我是pig8', '2017-05-24', '你是pig8'),
(10, 'pig9', 'pig9', '我是pig9', '2017-05-24', NULL),
(11, 'pig10', 'pig10', '我是pig10', '2017-05-24', '你是pig10'),
(12, 'pig11', 'pig11', NULL, NULL, NULL),
(13, 'pig12', 'pig12', NULL, NULL, NULL),
(14, 'pig13', 'pig13', NULL, NULL, NULL),
(15, 'pig14', 'pig14', NULL, NULL, NULL),
(16, 'pig15', 'pig15', NULL, NULL, NULL),
(17, 'pig16', 'pig16', NULL, NULL, NULL),
(18, 'pig17', 'pig17', NULL, NULL, NULL),
(19, 'pig18', 'pig18', NULL, NULL, NULL),
(20, 'pig19', 'pig19', NULL, NULL, NULL),
(21, 'pig20', 'pig20', NULL, NULL, NULL),
(22, 'pig21', 'pig21', NULL, NULL, NULL),
(23, 'pig22', 'pig22', NULL, NULL, NULL),
(24, 'pig23', 'pig23', NULL, NULL, NULL),
(25, 'pig24', 'pig24', NULL, NULL, NULL),
(26, 'pig25', 'pig25', NULL, NULL, NULL),
(27, 'pig26', 'pig26', NULL, NULL, NULL),
(28, 'pig27', 'pig27', NULL, NULL, NULL),
(29, 'pig28', 'pig28', NULL, NULL, NULL),
(30, 'pig29', 'pig29', NULL, NULL, NULL),
(31, 'pig30', 'pig30', NULL, NULL, NULL),
(32, 'pig31', 'pig31', NULL, NULL, NULL),
(33, 'pig32', 'pig32', NULL, NULL, NULL),
(34, 'pig33', 'pig33', NULL, NULL, NULL),
(35, 'pig34', 'pig34', NULL, NULL, NULL),
(36, 'pig35', 'pig35', NULL, NULL, NULL),
(37, 'pig36', 'pig36', NULL, NULL, NULL),
(38, 'pig37', 'pig37', NULL, NULL, NULL),
(39, 'pig38', 'pig38', NULL, NULL, NULL),
(40, 'pig39', 'pig39', NULL, NULL, NULL);
