;(function(window) {

  var svgSprite = '<svg>' +
    '' +
    '<symbol id="icon-tianmao" viewBox="0 0 1024 1024">' +
    '' +
    '<path d="M1017.052 340.533c-8.242-31.306-19.772-52.732-37.909-62.614-16.48-9.889-36.248-3.298-56.015 14.831l-31.313 36.245c-32.96 37.904-62.612 64.272-88.984 80.75-37.899 23.069-80.738 34.597-128.53 34.597L351.338 444.342c-46.132 0-88.989-14.828-128.525-44.485-18.135-14.831-47.792-46.144-88.989-92.278-31.308-34.609-60.969-44.495-87.328-29.659-18.126 9.882-29.656 31.308-37.894 62.614-4.954 23.068-6.6 49.437-6.6 77.451l0 74.152L0.36 492.137 0.36 633.84c0 31.315 6.585 54.382 19.767 70.858 11.53 13.18 28.01 23.068 52.728 24.72l265.306 3.291c25.621 2.332 45.312 9.108 59.056 20.049l231.208 0c13.743-10.941 33.435-17.717 59.064-20.049l265.297-3.291c24.717-1.652 41.193-11.541 52.732-24.72 13.182-16.478 18.121-39.543 18.121-70.858l0-215.855C1023.638 389.97 1021.996 363.601 1017.052 340.533zM122.288 647.024c-23.061-21.424-34.6-47.783-34.6-79.098 0-31.305 11.541-57.674 34.6-80.739 19.869-19.86 44.038-31.095 72.4-32.644-7.049 4.142-13.363 14.986-19.669 32.644-6.591 21.426-9.88 49.434-9.88 80.739 0 31.315 3.289 59.323 9.88 80.75 5.631 15.767 11.275 26.009 17.434 30.998C165.04 677.917 141.643 667.863 122.288 647.024zM282.126 647.024c-20.835 20.84-44.38 30.894-71.808 32.649 6.158-4.988 11.806-15.229 17.439-30.998 6.585-21.426 9.874-49.434 9.874-80.75 0-31.305-3.288-59.313-9.874-80.739-6.31-17.658-12.626-28.503-19.674-32.645 28.37 1.548 52.654 12.782 74.043 32.645 21.419 23.066 32.954 49.434 32.954 80.739C315.081 599.242 303.546 625.6 282.126 647.024zM478.22 543.213l13.182-3.293 41.196 0 13.177 3.293c3.293 3.296 1.646 6.596-1.641 9.889l-24.717 36.252c-1.661 1.652-3.303 3.291-6.595 3.291l-6.591-3.291-26.364-36.252C476.56 549.807 476.56 546.507 478.22 543.213zM633.104 689.871c-8.242 11.53-26.359 18.119-52.728 18.119-28.006 0-49.434-11.528-59.323-32.954l-1.637-1.643-6.595-3.298-1.647 0-6.596 3.298-1.641 1.643c-9.894 21.426-31.313 32.954-59.333 32.954-26.354 0-44.485-6.589-52.722-18.119l0-13.187c9.889 8.239 23.065 13.187 42.843 14.828 26.363 3.298 44.495-4.939 56.025-24.717 4.95-9.878 9.889-24.715 9.889-46.136l24.717 0L526 638.787c1.657 13.179 3.293 23.068 8.237 28.007 11.54 19.778 29.666 28.015 56.035 24.717 19.778-1.641 32.954-6.589 42.834-14.828l0 13.188L633.104 689.871zM743.513 647.024c-23.071-21.424-32.959-47.783-32.959-79.098 0-31.305 9.889-57.674 32.959-80.739 19.453-19.453 44.377-30.652 72.244-32.563-6.903 4.218-12.862 15.049-17.87 32.563-8.242 21.426-11.53 49.434-11.53 80.739 0 31.315 3.289 59.323 11.53 80.75 4.477 15.658 9.73 25.867 15.72 30.896C786.599 677.521 762.471 667.445 743.513 647.024zM903.351 647.024c-19.498 21.007-43.125 31.054-70.82 32.69 6.598-4.972 11.925-15.227 16.446-31.039 8.237-21.426 11.53-49.434 11.53-80.75 0-31.305-3.293-59.313-11.53-80.739-5.071-17.731-11.131-28.583-18.895-32.685 28.736 1.361 53.208 12.621 73.269 32.685 23.07 23.066 32.954 49.434 32.954 80.739C936.305 599.242 926.421 625.6 903.351 647.024z"  ></path>' +
    '' +
    '</symbol>' +
    '' +
    '</svg>'
  var script = function() {
    var scripts = document.getElementsByTagName('script')
    return scripts[scripts.length - 1]
  }()
  var shouldInjectCss = script.getAttribute("data-injectcss")

  /**
   * document ready
   */
  var ready = function(fn) {
    if (document.addEventListener) {
      if (~["complete", "loaded", "interactive"].indexOf(document.readyState)) {
        setTimeout(fn, 0)
      } else {
        var loadFn = function() {
          document.removeEventListener("DOMContentLoaded", loadFn, false)
          fn()
        }
        document.addEventListener("DOMContentLoaded", loadFn, false)
      }
    } else if (document.attachEvent) {
      IEContentLoaded(window, fn)
    }

    function IEContentLoaded(w, fn) {
      var d = w.document,
        done = false,
        // only fire once
        init = function() {
          if (!done) {
            done = true
            fn()
          }
        }
        // polling for no errors
      var polling = function() {
        try {
          // throws errors until after ondocumentready
          d.documentElement.doScroll('left')
        } catch (e) {
          setTimeout(polling, 50)
          return
        }
        // no errors, fire

        init()
      };

      polling()
        // trying to always fire before onload
      d.onreadystatechange = function() {
        if (d.readyState == 'complete') {
          d.onreadystatechange = null
          init()
        }
      }
    }
  }

  /**
   * Insert el before target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var before = function(el, target) {
    target.parentNode.insertBefore(el, target)
  }

  /**
   * Prepend el to target
   *
   * @param {Element} el
   * @param {Element} target
   */

  var prepend = function(el, target) {
    if (target.firstChild) {
      before(el, target.firstChild)
    } else {
      target.appendChild(el)
    }
  }

  function appendSvg() {
    var div, svg

    div = document.createElement('div')
    div.innerHTML = svgSprite
    svgSprite = null
    svg = div.getElementsByTagName('svg')[0]
    if (svg) {
      svg.setAttribute('aria-hidden', 'true')
      svg.style.position = 'absolute'
      svg.style.width = 0
      svg.style.height = 0
      svg.style.overflow = 'hidden'
      prepend(svg, document.body)
    }
  }

  if (shouldInjectCss && !window.__iconfont__svg__cssinject__) {
    window.__iconfont__svg__cssinject__ = true
    try {
      document.write("<style>.svgfont {display: inline-block;width: 1em;height: 1em;fill: currentColor;vertical-align: -0.1em;font-size:16px;}</style>");
    } catch (e) {
      console && console.log(e)
    }
  }

  ready(appendSvg)


})(window)